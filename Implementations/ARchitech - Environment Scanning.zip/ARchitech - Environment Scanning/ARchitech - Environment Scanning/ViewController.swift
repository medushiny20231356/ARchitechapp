//
//  ViewController.swift
//  ARchitech - Environment Scanning
//
//  Created by Nikitha Randinu Wadisinha on 2026-01-20.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate {

    // 1. UI Connections
    @IBOutlet var sceneView: ARSCNView!
    @IBOutlet weak var actionButton: UIButton!
    
    // 2. App State (Scanning vs Viewing)
    enum AppState {
        case scanning
        case viewing
    }
    var currentState: AppState = .scanning

    // 3. View Loading
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        sceneView.delegate = self
        
        // Add default lighting so the 3D model has depth (shadows)
        sceneView.autoenablesDefaultLighting = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Start scanning immediately when the app opens
        startScanning()
    }
    
    // 4. The Button Logic
    @IBAction func toggleScan(_ sender: UIButton) {
        if currentState == .scanning {
            // switch to VIEWING mode
            currentState = .viewing
            sender.setTitle("Reset & Scan Again", for: .normal)
            
            // Pause the AR session (stop adding new mesh)
            sceneView.session.pause()
            
            // Turn the background Dark Gray (hide the real world camera)
            sceneView.scene.background.contents = UIColor.darkGray
            
            // Allow the user to rotate/zoom the model with fingers
            sceneView.allowsCameraControl = true
            
        } else {
            // switch back to SCANNING mode
            currentState = .scanning
            sender.setTitle("Stop & View Model", for: .normal)
            
            // Turn off finger control (AR takes over)
            sceneView.allowsCameraControl = false
            
            // Reset background to camera feed
            sceneView.scene.background.contents = nil
            
            // Remove old mesh nodes
            sceneView.scene.rootNode.enumerateChildNodes { (node, stop) in
                node.removeFromParentNode()
            }
            
            // Restart the scan
            startScanning()
        }
    }
    
    // 5. Helper Function to Start AR
    func startScanning() {
        let configuration = ARWorldTrackingConfiguration()
        
        // Check if device supports LiDAR Scene Reconstruction
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            configuration.sceneReconstruction = .mesh
        } else {
            print("Error: This device does not support LiDAR scanning.")
        }
        
        // Run the session
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    }

    // MARK: - ARSCNViewDelegate (LiDAR Mesh Generation)
    
    // This runs when LiDAR detects a NEW surface
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        guard let meshAnchor = anchor as? ARMeshAnchor else { return nil }
        
        // Create the 3D shape from LiDAR data
        let geometry = SCNGeometry(arGeometry: meshAnchor.geometry)
        
        // Color it Cyan so we can see it
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.cyan.withAlphaComponent(0.8)
        material.lightingModel = .physicallyBased
        geometry.materials = [material]
        
        let node = SCNNode(geometry: geometry)
        return node
    }
    
    // This runs when LiDAR UPDATES an existing surface (makes it more detailed)
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let meshAnchor = anchor as? ARMeshAnchor else { return }
        
        // Update the shape
        node.geometry = SCNGeometry(arGeometry: meshAnchor.geometry)
        
        // Re-apply color
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.cyan.withAlphaComponent(0.8)
        node.geometry?.materials = [material]
    }
}

// MARK: - Helper Extension
// This converts raw Apple AR data into SceneKit 3D shapes
extension SCNGeometry {
    convenience init(arGeometry: ARMeshGeometry) {
        let verticesSource = SCNGeometrySource(buffer: arGeometry.vertices.buffer,
                                               vertexFormat: arGeometry.vertices.format,
                                               semantic: .vertex,
                                               vertexCount: arGeometry.vertices.count,
                                               dataOffset: arGeometry.vertices.offset,
                                               dataStride: arGeometry.vertices.stride)
        
        let normalsSource = SCNGeometrySource(buffer: arGeometry.normals.buffer,
                                              vertexFormat: arGeometry.normals.format,
                                              semantic: .normal,
                                              vertexCount: arGeometry.normals.count,
                                              dataOffset: arGeometry.normals.offset,
                                              dataStride: arGeometry.normals.stride)
        
        // We create a Data object from the raw pointer
        let facesData = Data(bytes: arGeometry.faces.buffer.contents(), count: arGeometry.faces.buffer.length)
        
        let facesElement = SCNGeometryElement(data: facesData,
                                              primitiveType: .triangles,
                                              primitiveCount: arGeometry.faces.count,
                                              bytesPerIndex: arGeometry.faces.bytesPerIndex)
        
        self.init(sources: [verticesSource, normalsSource], elements: [facesElement])
    }
}
