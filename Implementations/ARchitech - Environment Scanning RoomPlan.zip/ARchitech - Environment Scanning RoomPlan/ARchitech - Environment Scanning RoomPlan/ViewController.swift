//
//  ViewController.swift
//  ARchitech - Environment Scanning RoomPlan
//
//  Created by Nikitha Randinu Wadisinha on 2026-01-20.
//

import UIKit
import RoomPlan // The new Framework

class ViewController: UIViewController, RoomCaptureViewDelegate, RoomCaptureSessionDelegate {
    
    // 1. UI Elements
    @IBOutlet weak var actionButton: UIButton!
    
    // We create the scanner view in code, not storyboard
    var roomCaptureView: RoomCaptureView!
    var captureSessionConfig: RoomCaptureSession.Configuration!
    
    // 2. Track State
    var isScanning = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // A. Setup the RoomPlan View
        // This creates a full-screen view that handles the camera and scanning visuals automatically
        roomCaptureView = RoomCaptureView(frame: view.bounds)
        
        // Style it (optional)
        roomCaptureView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.insertSubview(roomCaptureView, at: 0) // Put it BEHIND the button
        
        // B. Setup Delegates (Listeners)
        roomCaptureView.captureSession.delegate = self
        roomCaptureView.delegate = self
        
        // C. Configure the button
        actionButton.layer.cornerRadius = 10
        actionButton.backgroundColor = .systemBlue
        actionButton.setTitleColor(.white, for: .normal)
        actionButton.setTitle("Start Scanning", for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // We don't start automatically anymore; we wait for the button press.
    }
    
    // MARK: - Button Logic
    @IBAction func toggleScan(_ sender: UIButton) {
        if !isScanning {
            // --- START SCANNING ---
            isScanning = true
            sender.setTitle("Done & View", for: .normal)
            sender.backgroundColor = .systemRed
            
            // Start the RoomPlan session
            captureSessionConfig = RoomCaptureSession.Configuration()
            roomCaptureView.captureSession.run(configuration: captureSessionConfig)
            
        } else {
            // --- STOP & VIEW ---
            isScanning = false
            sender.setTitle("Start New Scan", for: .normal)
            sender.backgroundColor = .systemBlue
            
            // Stop the session.
            // RoomPlan automatically freezes the model on screen so you can inspect it.
            roomCaptureView.captureSession.stop()
        }
    }
    
    // MARK: - RoomPlan Delegate Methods
    // These run automatically when the scan finishes processing
    
    func captureView(shouldPresent roomDataForProcessing: CapturedRoomData, error: Error?) -> Bool {
        // This allows the app to show the "Final" processed version of the room
        return true
    }
    
    func captureView(didPresent processedResult: CapturedRoom, error: Error?) {
        print("Final model displayed. Walls found: \(processedResult.walls.count)")
    }
}
